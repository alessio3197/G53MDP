package com.example.aless.g53mdpcw3;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBHelper extends SQLiteOpenHelper {

    public DBHelper(Context context, String name, CursorFactory factory,
                    int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE recipes (" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT ," +
                "title VARCHAR(128) NOT NULL," +
                "instructions VARCHAR(8192) NOT NULL," + //Has to be big because multiline string
                "rating INTEGER NOT NULL" +
                ");");

        db.execSQL("INSERT INTO recipes (title, instructions, rating) VALUES ('Toast', '1. Put bread in toaster\n2. Done', 3);");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS recipes");
        onCreate(db);
    }
}