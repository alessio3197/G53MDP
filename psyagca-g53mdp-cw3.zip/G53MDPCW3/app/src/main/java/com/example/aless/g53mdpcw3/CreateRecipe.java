package com.example.aless.g53mdpcw3;

import android.content.ContentValues;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class CreateRecipe extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_recipe);
    }

    public void onClickSaveRec(View v){
        final EditText title = (EditText) findViewById(R.id.titleEntry);
        final EditText instructions = (EditText) findViewById(R.id.instructionsEntry);
        ContentValues newValues = new ContentValues();
        newValues.put(RecipeProviderContract.TITLE, title.getText().toString());
        newValues.put(RecipeProviderContract.INSTRUCTIONS, instructions.getText().toString());
        newValues.put(RecipeProviderContract.RATING, 3);

        getContentResolver().insert(RecipeProviderContract.RECIPES_URI, newValues);

        finish();
    }
}
