package com.example.aless.g53mdpcw3;

import android.content.Intent;
import android.database.ContentObserver;
import android.database.Cursor;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

public class MainActivity extends AppCompatActivity {

    SimpleCursorAdapter dataAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String[] projection = new String[] {
                RecipeProviderContract._ID,
                RecipeProviderContract.TITLE,
                RecipeProviderContract.INSTRUCTIONS,
                RecipeProviderContract.RATING
        };

        String colsToDisplay [] = new String[] {
                RecipeProviderContract.TITLE,
                RecipeProviderContract.RATING
        };

        int[] colResIds = new int[] {
                R.id.value1,
                R.id.value2
        };

        Cursor cursor = getContentResolver().query(RecipeProviderContract.RECIPES_URI, projection, null, null, null);

        dataAdapter = new SimpleCursorAdapter(
                this,
                R.layout.item_layout,
                cursor,
                colsToDisplay,
                colResIds,
                0);

        final ListView listView = (ListView) findViewById(R.id.recipeList);
        listView.setAdapter(dataAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> myAdapter,
                                    View myView,
                                    int myItemInt,
                                    long mylng) {
                Bundle bundle = new Bundle();
                Cursor selected = (Cursor) (listView.getItemAtPosition(myItemInt));
                bundle.putString("id", selected.getString(0));
                //Log.d("check1",selected.getString(0));
                Intent viewIntent = new Intent(MainActivity.this, ViewRecipe.class);
                viewIntent.putExtras(bundle);
                startActivity(viewIntent);
            }
        });

        ChangeObserver observer = new ChangeObserver(new Handler());
        getContentResolver().registerContentObserver(RecipeProviderContract.ALL_URI, true, observer);

        queryRecipes();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    class ChangeObserver extends ContentObserver {
        ChangeObserver(Handler handler) {
            super(handler);
        }

        @Override
        public void onChange(boolean selfChange) {
            super.onChange(selfChange);
            queryRecipes();
        }
    }

    public void queryRecipes() {

        String[] projection = new String[] {
                RecipeProviderContract._ID,
                RecipeProviderContract.TITLE,
                RecipeProviderContract.INSTRUCTIONS,
                RecipeProviderContract.RATING
        };

        Cursor cursor = getContentResolver().query(RecipeProviderContract.RECIPES_URI, projection, null, null, null);
        dataAdapter.changeCursor(cursor);
    }


    public void onNewRecClick(View v){
        Intent recIntent = new Intent(this, CreateRecipe.class);
        startActivity(recIntent);
    }

    public void onSortByRecClick(View v){
        String[] projection = new String[] {
                RecipeProviderContract._ID,
                RecipeProviderContract.TITLE,
                RecipeProviderContract.INSTRUCTIONS,
                RecipeProviderContract.RATING
        };

        Cursor cursor = getContentResolver().query(RecipeProviderContract.RECIPES_URI, projection, null, null, RecipeProviderContract.TITLE+" COLLATE NOCASE ASC");
        dataAdapter.changeCursor(cursor);
    }

    public void onSortByRatClick(View v){
        String[] projection = new String[] {
                RecipeProviderContract._ID,
                RecipeProviderContract.TITLE,
                RecipeProviderContract.INSTRUCTIONS,
                RecipeProviderContract.RATING
        };

        Cursor cursor = getContentResolver().query(RecipeProviderContract.RECIPES_URI, projection, null, null, RecipeProviderContract.RATING + " COLLATE NOCASE DESC");
        dataAdapter.changeCursor(cursor);
    }
}
