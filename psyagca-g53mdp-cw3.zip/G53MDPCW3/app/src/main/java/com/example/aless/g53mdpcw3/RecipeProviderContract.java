package com.example.aless.g53mdpcw3;

import android.net.Uri;

public class RecipeProviderContract {

    public static final String AUTHORITY = "com.example.aless.g53mdpcw3.RecipeProvider";

    public static final Uri RECIPES_URI = Uri.parse("content://"+AUTHORITY+"/recipes");
    public static final Uri ALL_URI = Uri.parse("content://"+AUTHORITY+"/");

    public static final String _ID = "_id";

    public static final String TITLE = "title";
    public static final String INSTRUCTIONS = "instructions";
    public static final String RATING = "rating";

    public static final String CONTENT_TYPE_SINGLE = "vnd.android.cursor.item/RecipeProvider.data.text";
    public static final String CONTENT_TYPE_MULTIPLE = "vnd.android.cursor.dir/RecipeProvider.data.text";
}