package com.example.aless.g53mdpcw3;

import android.content.ContentValues;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RatingBar;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

public class ViewRecipe extends AppCompatActivity {

    SimpleCursorAdapter dataAdapter;

    String selectedID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_recipe);

        Bundle bundle = getIntent().getExtras();
        String givenId = bundle.getString("id");

        String[] projection = new String[] {
                RecipeProviderContract._ID,
                RecipeProviderContract.TITLE,
                RecipeProviderContract.INSTRUCTIONS,
                RecipeProviderContract.RATING
        };

        Cursor cursor = getContentResolver().query(RecipeProviderContract.RECIPES_URI, projection, null, null, null);

        cursor.moveToFirst();
        while(true) {
            if (cursor.getString(0).equals(givenId)) {
                selectedID = givenId;
                TextView title = (TextView) findViewById(R.id.titleViewTag);
                title.setText(cursor.getString(1));
                TextView instructions = (TextView) findViewById(R.id.instructionsViewTag);
                instructions.setText(cursor.getString(2));
                RatingBar rating = (RatingBar) findViewById(R.id.ratingBar);
                rating.setRating(Float.valueOf(cursor.getString(3)));
                break;
            }
            try {
                cursor.moveToNext();
            }catch (Exception e){break;}
        }

    }

    public void onClickSaveRating(View v){
        RatingBar rating = (RatingBar) findViewById(R.id.ratingBar);
        String newRating = String.valueOf(rating.getRating());
        ContentValues newValues = new ContentValues();
        newValues.put(RecipeProviderContract.RATING, newRating);
        getContentResolver().update(RecipeProviderContract.RECIPES_URI,newValues,RecipeProviderContract._ID+"=?",new String[] {selectedID});
        finish();
    }

    public void onClickDeleteRec(View v){
        getContentResolver().delete(RecipeProviderContract.RECIPES_URI,RecipeProviderContract._ID+"=?",new String[] {selectedID});
        finish();
    }
}
